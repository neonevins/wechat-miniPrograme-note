# MPVUE 讲解

### 1. mpvue安装

1. `npm i vue-cli -g`
2. ` vue init mpvue/mpvue-quickstart my-project`
3. $ cd my-project
   $ npm install
4. $ npm run dev

### 2. 微信自带设备方法

* 地图

	wx.createMapContext(string mapId, Object this)

```js

```

* 相机